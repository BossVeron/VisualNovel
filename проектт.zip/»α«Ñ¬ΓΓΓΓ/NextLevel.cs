﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextLevel : MonoBehaviour {
    public int level;
	void Start () {
		
	}


    void Update () {
        if (Input.GetKeyDown(KeyCode.W))
            {
            SceneManager.LoadScene(level);
        }

	}
}
